<?php
// Start the session
session_start();

// Check if the user has clicked the logout link
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    // Destroy the session and logout the user
    session_unset();  // Unset all session variables
    session_destroy();  // Destroy the session

    // Set a success message in the session
    $_SESSION['logout_success'] = "Logout Successful!";
    
    // Redirect to the same page to show the logout success message
    header("Location: logout.php");
    exit();
}

// Check if there's a logout success message to display
$logout_message = isset($_SESSION['logout_success']) ? $_SESSION['logout_success'] : '';

// Clear the success message after displaying it
unset($_SESSION['logout_success']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            text-align: center;
            padding: 50px;
        }

        .message {
            background-color: #d4edda;
            color: #155724;
            padding: 20px;
            border-radius: 5px;
            border: 1px solid #c3e6cb;
            display: inline-block;
            font-size: 18px;
        }

        .redirect-link {
            display: block;
            margin-top: 20px;
            color: #007bff;
            font-size: 16px;
            text-decoration: none;
        }

        .redirect-link:hover {
            text-decoration: underline;
        }

        .logout-button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }

        .logout-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<?php if ($logout_message): ?>
    <div class="message">
        <p><?php echo $logout_message; ?></p>
        <a href="index.php" class="redirect-link">Click here to login again.</a>
    </div>
<?php else: ?>
    <a href="?action=logout" class="logout-button">Logout</a>
<?php endif; ?>

</body>
</html>
