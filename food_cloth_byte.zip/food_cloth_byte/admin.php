<?php
session_start();
require 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit();
}

// Handle product addition
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    // Handle file upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_name = time() . '_' . $_FILES['image']['name'];
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($image_name);

        // Move file to upload directory
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image_path = $target_file;
        } else {
            $error = "Failed to upload image.";
        }
    } else {
        $error = "Image is required.";
    }

    if (empty($error)) {
        $stmt = $conn->prepare("INSERT INTO products (name, category, price, stock, image) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $category, $price, $stock, $image_path]);
        $success = "Product added successfully!";
    }
}

// Handle product update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_product'])) {
    $product_id = $_POST['product_id'];
    $name = $_POST['name'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    // Handle file upload for image update
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_name = time() . '_' . $_FILES['image']['name'];
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($image_name);

        // Move file to upload directory
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image_path = $target_file;
        } else {
            $error = "Failed to upload image.";
        }
    } else {
        // If no new image, keep the old one
        $stmt = $conn->prepare("SELECT image FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();
        $image_path = $product['image']; // Keep the old image if no new image is uploaded
    }

    if (empty($error)) {
        $stmt = $conn->prepare("UPDATE products SET name = ?, category = ?, price = ?, stock = ?, image = ? WHERE id = ?");
        $stmt->execute([$name, $category, $price, $stock, $image_path, $product_id]);
        $success = "Product updated successfully!";
    }
}

// Handle product deletion (Solution 1 - Manually handle cart references)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product'])) {
    $product_id = $_POST['product_id'];

    // Step 1: Delete product references from the cart
    $stmt = $conn->prepare("DELETE FROM cart WHERE product_id = ?");
    $stmt->execute([$product_id]);

    // Step 2: Delete the product from the products table
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$product_id]);

    $success = "Product and its references in cart deleted successfully!";
}

// Fetch all products
$stmt = $conn->prepare("SELECT * FROM products");
$stmt->execute();
$products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Admin - Manage Products</title>
</head>
<body>
    <!-- Topbar -->
    <div class="topbar">
        <a href="admin.php" class="logo">Admin Panel</a>
        <nav>
            <ul>
               
                <li><a href="adminorders.php">View Orders</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </div>

    <div class="container">
        <h1>Manage Products</h1>
        <?php if (!empty($success)) echo "<p class='success'>$success</p>"; ?>
        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>

        <!-- Add Product Form -->
        <form method="POST" enctype="multipart/form-data" style="margin-bottom: 20px;">
            <h2>Add Product</h2>
            <input type="text" name="name" placeholder="Product Name" required>
            <select name="category" required>
                <option value="food">Food</option>
                <option value="cloth">Cloth</option>
            </select>
            <input type="number" name="price" placeholder="Price" step="0.01" required>
            <input type="number" name="stock" placeholder="Stock" required>
            <input type="file" name="image" required>
            <button type="submit" name="add_product">Add Product</button>
        </form>

        <!-- Product List -->
        <h2>Product List</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td><?= htmlspecialchars($product['id']) ?></td>
                        <td><?= htmlspecialchars($product['name']) ?></td>
                        <td><?= htmlspecialchars($product['category']) ?></td>
                        <td>$<?= number_format($product['price'], 2) ?></td>
                        <td><?= htmlspecialchars($product['stock']) ?></td>
                        <td>
                            <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" style="width: 50px; height: 50px;">
                        </td>
                        <td>
                            <!-- Edit Form -->
                            <button onclick="document.getElementById('edit_<?= $product['id'] ?>').style.display='block'">Edit</button>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                <button type="submit" name="delete_product" style="background-color: red;">Delete</button>
                            </form>

                            <!-- Edit Product Form (Hidden) -->
                            <div id="edit_<?= $product['id'] ?>" style="display:none; margin-top: 20px;">
                                <form method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                    <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>
                                    <select name="category" required>
                                        <option value="food" <?= $product['category'] === 'food' ? 'selected' : '' ?>>Food</option>
                                        <option value="cloth" <?= $product['category'] === 'cloth' ? 'selected' : '' ?>>Cloth</option>
                                    </select>
                                    <input type="number" name="price" value="<?= htmlspecialchars($product['price']) ?>" step="0.01" required>
                                    <input type="number" name="stock" value="<?= htmlspecialchars($product['stock']) ?>" required>
                                    <input type="file" name="image">
                                    <button type="submit" name="update_product">Update Product</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Script to toggle edit form visibility -->
    <script>
        function toggleEditForm(productId) {
            var editForm = document.getElementById('edit_' + productId);
            editForm.style.display = (editForm.style.display === 'block') ? 'none' : 'block';
        }
    </script>
</body>
</html>
