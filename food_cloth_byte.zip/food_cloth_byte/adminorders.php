<?php
session_start();
require 'db.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

// Check if the logged-in user is an admin
$is_admin = ($user_role === 'admin');

// Fetch orders
if ($is_admin) {
    // Admin can view all orders
    $stmt = $conn->prepare("SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.order_date DESC");
} else {
    // Regular users can only view their own orders
    $stmt = $conn->prepare("SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id = u.id WHERE o.user_id = ? ORDER BY o.order_date DESC");
    $stmt->execute([$user_id]);
}

$stmt->execute();
$orders = $stmt->fetchAll();

// Handle marking an order as shipped (Admin Only)
if ($is_admin && isset($_POST['mark_shipped'])) {
    $order_id = $_POST['order_id'];

    // Update order status to 'shipped'
    $stmt = $conn->prepare("UPDATE orders SET status = 'shipped' WHERE id = ?");
    $stmt->execute([$order_id]);

    $success = "Order marked as shipped!";
    // Redirect to the same page after update
    header('Location: adminorders.php');
    exit();
}

// Handle updating the order status (Admin Only)
if ($is_admin && isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];

    // Update order status
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$new_status, $order_id]);

    $success = "Order status updated!";
    // Redirect to the same page after update
    header('Location: adminorders.php');
    exit();
}

// Handle deleting the order (Admin Only)
if ($is_admin && isset($_POST['delete_order'])) {
    $order_id = $_POST['order_id'];

    // Delete the order
    $stmt = $conn->prepare("DELETE FROM orders WHERE id = ?");
    $stmt->execute([$order_id]);

    $success = "Order deleted successfully!";
    // Redirect to the same page after delete
    header('Location: adminorders.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Orders</title>
</head>
<body>
    <!-- Topbar -->
    <div class="topbar">
        <a href="index.php" class="logo">FoodByte</a>
        <nav>
            <ul>
                <li><a href="admin.php">Admin Panel</a></li>
                <li><a href="adminorders.php">View Orders</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </div>

    <div class="container">
        <h1>Orders</h1>
        <?php if (!empty($success)) echo "<p class='success'>$success</p>"; ?>

        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>User</th>
                    <th>Order Date</th>
                    <th>Status</th>
                    <th>Total Amount</th>
                    <?php if ($is_admin): ?>
                        <th>Actions</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= htmlspecialchars($order['id']) ?></td>
                        <td><?= htmlspecialchars($order['username']) ?></td>
                        <td><?= date('Y-m-d H:i:s', strtotime($order['order_date'])) ?></td>
                        <td><?= htmlspecialchars($order['status']) ?></td>
                        <td>$<?= number_format($order['total_amount'], 2) ?></td>
                        <?php if ($is_admin): ?>
                            <td>
                                <!-- Dropdown to change the status -->
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                    <select name="status">
                                        <option value="pending" <?= $order['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                                        <option value="shipped" <?= $order['status'] === 'shipped' ? 'selected' : '' ?>>Shipped</option>
                                        <option value="delivered" <?= $order['status'] === 'delivered' ? 'selected' : '' ?>>Delivered</option>
                                    </select>
                                    <button type="submit" name="update_status">Update Status</button>
                                </form>

                                <!-- Delete Order Form -->
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                    <button type="submit" name="delete_order" style="background-color: red; color: white;">Delete</button>
                                </form>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
