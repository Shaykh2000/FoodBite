<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle Add to Cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Check if product already in cart
    $stmt = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
    $stmt->execute([$user_id, $product_id]);
    $cart_item = $stmt->fetch();

    if ($cart_item) {
        $stmt = $conn->prepare("UPDATE cart SET quantity = quantity + ? WHERE id = ?");
        $stmt->execute([$quantity, $cart_item['id']]);
    } else {
        $stmt = $conn->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $product_id, $quantity]);
    }

    $success = "Product added to cart!";
}

// Fetch products with search, sorting, and pagination
$search = $_GET['search'] ?? '';
$sort = $_GET['sort'] ?? 'name';
$page = $_GET['page'] ?? 1;
$per_page = 6;
$offset = ($page - 1) * $per_page;

$query = "SELECT * FROM products WHERE name LIKE ? ORDER BY $sort LIMIT $offset, $per_page";
$stmt = $conn->prepare($query);
$stmt->execute(["%$search%"]);
$products = $stmt->fetchAll();

// Get total product count for pagination
$total_stmt = $conn->prepare("SELECT COUNT(*) FROM products WHERE name LIKE ?");
$total_stmt->execute(["%$search%"]);
$total_products = $total_stmt->fetchColumn();
$total_pages = ceil($total_products / $per_page);
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Shop</title>
</head>
<body>
    <!-- Topbar -->
    <div class="topbar">
        <a href="shop.php" class="logo">Shop</a>
        <nav>
            <ul>
                <li><a href="shop.php">Home</a></li>
                <li><a href="userorder.php">Orders</a></li>
                <li><a href="cart.php">Cart</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </div>

    <div class="container">
        <h1>Shop</h1>
        <?php if (!empty($success)) echo "<p class='success'>$success</p>"; ?>

        <!-- Search and Sort -->
        <form method="GET" style="margin-bottom: 20px;">
            <input type="text" name="search" placeholder="Search products" value="<?= htmlspecialchars($search) ?>">
            <select name="sort">
                <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>Sort by Name</option>
                <option value="price" <?= $sort === 'price' ? 'selected' : '' ?>>Sort by Price</option>
            </select>
            <button type="submit">Apply</button>
        </form>

        <!-- Product Display -->
        <div class="product-grid">
            <?php if (empty($products)): ?>
                <p>No products found.</p>
            <?php else: ?>
                <?php foreach ($products as $product): ?>
                    <div class="product-card">
                        <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                        <h3><?= htmlspecialchars($product['name']) ?></h3>
                        <p>Category: <?= htmlspecialchars($product['category']) ?></p>
                        <p>Price: $<?= number_format($product['price'], 2) ?></p>
                        <form method="POST">
                            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                            <input type="number" name="quantity" value="1" min="1" style="width: 50px;">
                            <button type="submit" name="add_to_cart">Add to Cart</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <div class="pagination">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?search=<?= htmlspecialchars($search) ?>&sort=<?= htmlspecialchars($sort) ?>&page=<?= $i ?>"
                   class="<?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
        </div>
    </div>
</body>
</html>
